import random

niv1 = []
niv2 = []
niv3 = []
# Choix du mot au hasard
mots = []
"""
Objectifs: choisir un mots parmi ceux du fichier.txt ,ranger selon leur taille dans differentes listes.
Methode: on utilise with open pour utiliser notre fichier texte on utilise un for pour parcourir les mots et selon leur taille avec un if la fonction len on les ranges dans une des liste.
Besoins: la fontion len , fl qui represente l'ensemble des  mots du fichier texte et l qui represente chaque mot.
Connus: l,fl
Entrees: l,fl
Sorties:/
Resultat: les listes niv1,niv2,niv3.
Hypothese:/
"""
with open("venv/bootcamp/mots.txt") as fl:
    for l in fl:
        if len(l) <= 4:
            niv1.append(l)

        elif 5 >= len(l) < 7:
            niv2.append(l)
        else:
            niv3.append(l)

# Variables cles

niveau = 0
voyelle = ['a', 'e', 'i', 'u', 'o', 'y']
lettres = []
lettres_trouves = set()
faux = 0
trouve = False
corps_plein = ["0", "/", "|", "\\", "/", "\\"]
corps = [" ", " ", " ", " ", " ", " "]
cpt = 0
score = 0
print("BIENVENU DANS LE JEU LET-GET")
print("#######################################")
print("Vous avez 3 point-erreur")
print("######################################")
print("Vous avez 6 tentatives")
print("#####################################\n ")
niveau = int(input("Choisir un niveau de jeu de 1 a 3: "))

"""
    Objectifs: Choisir aleatoirement dans la liste niv1 des mots ,puis demander a l'utilisateur de saisir des lettre en vue de trouver le mot,calculer son score et le lui afficher.
    Methode: random.choice pour le choix au hasard,
    Besoins: l,mot,lettres,faux,score,
    Connus: mot
    Entrees: mot,lettre :saisi par le joueur
    Sorties:score,
    Resultat: gagné ou perdu
    Hypothese:/
"""
if niveau == 1:
    mot = random.choice(niv1)
    liste=list(mot)
    liste.pop(-1)
    print("Vous avez choisi le niveau 1 je vous propose donc des mots de moins de 2 a 4 lettres")
    while not trouve:
        trouve = True

        print("+---+")
        print("|   |")
        print("|   {}".format(corps[0]))
        print("|  {}{}{}".format(corps[1], corps[2], corps[3]))
        print("|  {} {}".format(corps[4], corps[5]))
        print("|")
        print("|")
        print("==========")
        lettres_trouves.add(l)
        for i in liste:
            if i in lettres:
                print(i, end=" ")
            else:
                trouve = False
                print("_", end=" ")

        print()
        print("lettres utilises - ", end="")
        for l in lettres:
            print(l, end=" | ")
        print()

        if faux > 5:
            print("Tu as perdu ")
            print("Le mot etait  - {}".format(mot))
            print(f"Votre score est de : {score} ")
            break
        if trouve:
            print("BRAVO! Vous avez devine le mot")
            print("################################")
            print(f"Votre score est de : {score} ")

            break
        lettre = input("Saisir une lettre : ")
        lettres.append(lettre)

        if lettre not in mot:
            cpt = cpt + 1
            corps[faux] = corps_plein[faux]
            faux += 1
            if lettre in voyelle:
                print("Vous avez saisie une voyelle qui n'est pas dans le mot")
                print("#########################################################")
                print("Vous perdez une tentative")
            else:
                print("Vous avez saisie une consonne qui n'est pas dans le mot")
                print("Vous perdez une tentatives")
        elif lettre in lettres_trouves:
            print("Vous avez deja saisie cette lettre")
        else:
            if lettre in voyelle:
                print("une voyelle de correcte! Continuer")
            else:
                print("une consonne de correcte! Continuer")
            print()
        score = len(mot) * (6 - cpt)

elif niveau == 2:
    """
        Objectifs: Choisir aleatoirement dans la liste niv2 des mots ,puis demander a l'utilisateur de saisir des lettre en vue de trouver le mot,calculer son score et le lui afficher.
        Methode: random.choice pour le choix au hasard,
        Besoins: l,mot,lettres,faux,score,cpt
        Connus: mot
        Entrees: lettre :saisi par le joueur,mot
        Sorties:score,
        Resultat: gagné ou perdu
        Hypothese:/
    """
    cpt = 0
    mot = random.choice(niv2)
    liste = list(mot)
    liste.pop(-1)
    print("Vous avez choisi le niveau 2 je vous propose donc des mots de 5 a 7 lettres")
    while not trouve:
        trouve = True

        print("+---+")
        print("|   |")
        print("|   {}".format(corps[0]))
        print("|  {}{}{}".format(corps[1], corps[2], corps[3]))
        print("|  {} {}".format(corps[4], corps[5]))
        print("|")
        print("|")
        print("==========")
        lettres_trouves.add(l)
        for i in liste:
            if i in lettres:
                print(i, end=" ")
            else:
                trouve = False
                print("_", end=" ")

        print()
        print("lettres utilises - ", end="")
        for l in lettres:
            print(l, end=" | ")
        print()

        if faux > 5:
            print("Tu as perdu ")
            print("Le mot etait  - {}".format(mot))
            print(f"Votre score est de : {score} ")
            break
        if trouve:
            print("BRAVO! Vous avez devine le mot")
            print("################################")
            print(f"Votre score est de : {score} ")

            break
        lettre = input("Saisir une lettre : ")
        lettres.append(lettre)

        if lettre not in mot:
            cpt = cpt + 1
            corps[faux] = corps_plein[faux]
            faux += 1
            if lettre in voyelle:
                print("Vous avez saisie une voyelle qui n'est pas dans le mot")
                print("#########################################################")
                print("Vous perdez une tentative")
            else:
                print("Vous avez saisie une consonne qui n'est pas dans le mot")
                print("Vous perdez une tentatives")
        elif lettre in lettres_trouves:
            print("Vous avez deja saisie cette lettre")
        else:
            if lettre in voyelle:
                print("une voyelle de correcte! Continuer")
            else:
                print("une consonne de correcte! Continuer")
            print()
        score = len(mot) * (6 - cpt)

elif niveau == 3:
    """
        Objectifs: Choisir aleatoirement dans la liste niv3 des mots ,puis demander a l'utilisateur de saisir des lettre en vue de trouver le mot,calculer son score et le lui afficher.
        Methode: random.choice pour le choix au hasard,
        Besoins: l,mot,lettres,faux,score,cpt
        Connus: mot
        Entrees: lettre :saisi par le joueur,mot
        Sorties:score,
        Resultat: gagné ou perdu
        Hypothese:/
        
    """
    cpt = 0
    mot = random.choice(niv3)
    liste = list(mot)
    liste.pop(-1)
    print("Vous avez choisi le niveau 3 je vous propose donc des mots de plus de 7 lettres")
    while not trouve:
        trouve = True

        print("+---+")
        print("|   |")
        print("|   {}".format(corps[0]))
        print("|  {}{}{}".format(corps[1], corps[2], corps[3]))
        print("|  {} {}".format(corps[4], corps[5]))
        print("|")
        print("|")
        print("==========")
        lettres_trouves.add(l)
        for i in liste:
            if i in lettres:
                print(i, end=" ")
            else:
                trouve = False
                print("_", end=" ")

        print()
        print("lettres utilises - ", end="")
        for l in lettres:
            print(l, end=" | ")
        print()

        if faux > 5:
            print("Tu as perdu ")
            print("Le mot etait  - {}".format(mot))
            print(f"Votre score est de : {score} ")
            break
        if trouve:
            print("BRAVO! Vous avez devine le mot")
            print("################################")
            print(f"Votre score est de : {score} ")
            break
        lettre = input("Saisir une lettre : ")
        lettres.append(lettre)

        if lettre not in mot:
            cpt = cpt + 1
            corps[faux] = corps_plein[faux]
            faux += 1
            if lettre in voyelle:
                print("Vous avez saisie une voyelle qui n'est pas dans le mot")
                print("#########################################################")
                print("Vous perdez une tentative")
            else:
                print("Vous avez saisie une consonne qui n'est pas dans le mot")
                print("Vous perdez une tentatives")
        elif lettre in lettres_trouves:
            print("Vous avez deja saisie cette lettre")
        else:
            if lettre in voyelle:
                print("une voyelle de correcte! Continuer")
            else:
                print("une consonne de correcte! Continuer")
            print()
        score = len(mot) * (6 - cpt)
else:
    print("Ce niveau n'existe pas")
